package com.api.insightink;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InsightinkApplicationTests {

	@Test
	void contextLoads() {
	}

}
