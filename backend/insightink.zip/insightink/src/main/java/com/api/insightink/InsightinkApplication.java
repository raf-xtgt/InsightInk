package com.api.insightink;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InsightinkApplication {

	public static void main(String[] args) {
		SpringApplication.run(InsightinkApplication.class, args);
	}

}
