package com.api.insightink.insightInk;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InsightInkApplicationTests {

	@Test
	void contextLoads() {
	}

}
